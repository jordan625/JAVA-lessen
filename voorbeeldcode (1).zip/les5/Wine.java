public class Wine extends Alcohol{
  public Wine(){
    ml = 250;
    init();
  }
}
