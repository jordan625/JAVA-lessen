public class Whiskey extends BurningAlcohol{
  public Whiskey(){
    ml = 120;
    init();
  }


}
