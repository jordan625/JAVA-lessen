public class Beer extends Alcohol{
  public Beer(){
    ml = 330;
    init();
  }
}
