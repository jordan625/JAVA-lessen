public class Vodka extends BurningAlcohol{
  public Vodka(){
    ml = 330;
    init();
  }
}
