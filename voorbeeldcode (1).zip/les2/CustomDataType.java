public class CustomDataType{
  public void CustomDataType()
  {
    System.out.println("You can also create a CustomDataType");
  }
  public void repeat(int count)
  {
    for(int i = 0; i < count; i++)
    {
      System.out.println("you can make it do anything you want, like repeating a sentence");
    }
  }
}
